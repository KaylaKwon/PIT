package madmax;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class signupMgr {
	private DBConnectionMgr pool = null;
	private UserBean param;
	
	public signupMgr(){
		try{
			pool = DBConnectionMgr.getInstance();
		}catch(Exception e){
			System.out.println("Error : Exception");
		}
	}
	
	public void setParam (UserBean val) {param = val;}
	
	public boolean getResult() {
		   Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   boolean flag = false;
	       try {
	    	   conn = pool.getConnection();
	    	   String strQuery = "INSERT INTO usertable (Email, PassWord) "
	    	   		+ "VALUES('" +  
	    			   param.getEmail() + "','" + param.getPassWord() + "')";
	    	  
	    	   stmt = conn.createStatement();
	    	   //rs = 
	    	   stmt.executeUpdate(strQuery);////Query(strQuery);
	    	   flag = true;
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	       return flag;
	}
}
