package madmax;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

public class loginMgr {
	private DBConnectionMgr pool = null;
	private UserBean param;
	
	public loginMgr(){
		try{
			pool = DBConnectionMgr.getInstance();
		}catch(Exception e){
			System.out.println("Error : Exception");
		}
	}
	
	public void setParam (UserBean val) {param = val;}
	
	public boolean getResult() {
		   Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   boolean flag = false;
		   
	       try {
	    	   conn = pool.getConnection();
	    	   String strQuery = "select * from usertable where Email = '" + param.getEmail() + "' AND PassWord = '" + param.getPassWord() + "'";
	    	   System.out.println(strQuery);
	    	   stmt = conn.createStatement();
	    	   rs = stmt.executeQuery(strQuery);
			 
	    	   if(!rs.next()){}//�ƹ��͵� ���ϰ� ������
	    	   else if(param.getEmail() == rs.getString("Email")){}//�ƹ��͵� ���ϰ� ������
	    	   else if(param.getPassWord() == rs.getString("PassWord")){}//�ƹ��͵� ���ϰ� ������
	    	   else flag = true;
	    	   
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	       return flag;
	}
}
