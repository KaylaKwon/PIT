package madmax;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Date;
import java.util.Vector;

public class categoryMgr {
	
	private DBConnectionMgr pool = null;
	private String Email;
	private int UserId;
	private CategoryBean param;
	private String newCateName;
	private String oldCateName;
	
	public categoryMgr(){
		try{
			pool = DBConnectionMgr.getInstance();
		}catch(Exception e){
			System.out.println("Error : Exception");
		}
	}
	
	public void setParam (CategoryBean val) {param = val;}
	public void setEmail (String val) {Email = val;}
	public void setNewCateName(String val) {newCateName = val;}
	public void setOldCateName(String val) {oldCateName = val;}
	
	public Vector getList() {
		   Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   Vector vecList = null;	   
		   
	       try {
	    	  conn = pool.getConnection();
	    	  //1.
	    	  String strQuery = "select UserId from usertable where Email = '" + Email + "'";
	          stmt = conn.createStatement();
        	  rs = stmt.executeQuery(strQuery);
	          if(rs.next())
	        	  UserId = rs.getInt("UserId");
	          else{
	        	  pool.freeConnection(conn);
	        	  return null;
	          }
	          
	          //2. UserId
	    	  strQuery = "select * from categorytable where UserId = " + UserId;
	          stmt = conn.createStatement();
	          rs = stmt.executeQuery(strQuery);
	          vecList = new Vector();
			  while (rs.next()) {
	             CategoryBean bean = new CategoryBean();
	             bean.setCateId(rs.getInt("CateId"));
				 bean.setCateName(rs.getString("CateName"));
	 			 bean.setCateUpdateTime(rs.getString("CateUpdateTime"));
	 			 bean.setUserId(rs.getInt("UserId"));
	             vecList.add(bean);
	          }
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	       return vecList;
	}
	
	public CategoryBean getItem() {
		   Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   CategoryBean bean = new CategoryBean();
		   //System.out.println(param.getCateName());
		   
	       try {
	    	  conn = pool.getConnection();
	    	  String strQuery = "select UserId from usertable where Email = '" + Email + "'";
	          stmt = conn.createStatement();
	          rs = stmt.executeQuery(strQuery);
	          if(rs.next())
	        	  UserId = rs.getInt("UserId");
	          else{
	        	  pool.freeConnection(conn);
	        	  return null;
	          }
	    	  strQuery = "select * from categorytable where UserId = " + UserId + " AND CateName = '" + param.getCateName() + "'";
	    	  //System.out.println(UserId + " " + Email + " " + param.getCateName());
	          stmt = conn.createStatement();
	          rs = stmt.executeQuery(strQuery);
	          
	          if(!rs.next()) bean = null;
	          else{
	        	  bean.setCateId(rs.getInt("CateId"));
	        	  bean.setCateName(rs.getString("CateName"));
	        	  bean.setCateUpdateTime(rs.getDate("CateUpdateTime").toString());
	        	  bean.setUserId(rs.getInt("UserId"));
	        	  //System.out.println(bean.getCateName());
	          }
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	       return bean;
	}

	public boolean getCreate() {
	       Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   boolean flag = false;	   
		   
	       try {
	    	   conn = pool.getConnection();
		       String strQuery = "select UserId from usertable where Email = '" + Email + "'";
		       stmt = conn.createStatement();
		       rs = stmt.executeQuery(strQuery);
		       if(rs.next())
		    	   UserId = rs.getInt("UserId");
		       else{
		    	   pool.freeConnection(conn);
		    	   return false;
		       }
		       System.out.println(UserId);
		       param.setUserId(UserId);
		       //2. insert 
		       String time = CurTime.getTime();
		       strQuery = "insert into categorytable (UserId, CateName, CateUpdateTime) "
		    		   + "values (" + UserId + ", '" + param.getCateName() + "', '" + time + "')";
		       stmt = conn.createStatement();
		       stmt.executeUpdate(strQuery);
               flag = true;
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	      return flag;
	}
	
	public boolean getDelete() {
	       Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   boolean flag = false;	   
	       try {
	           conn = pool.getConnection();
	           //1.
		       String strQuery = "select UserId from usertable where Email = '" + Email + "'";
		       stmt = conn.createStatement();
		       rs = stmt.executeQuery(strQuery);
		       if(rs.next())
		    	   UserId = rs.getInt("UserId");
		       else{
		    	   pool.freeConnection(conn);
		    	   return false;
		       }
		       strQuery = "select CateName from categorytable where CateName = '" + param.getCateName() + "'";
		       stmt = conn.createStatement();
		       rs = stmt.executeQuery(strQuery);
		       if(rs.next())
		       {
		    	   
		       }
		       else{
		    	   pool.freeConnection(conn);
		    	   return false;
		       }
		       
		       //delete &
		       strQuery = "delete from categorytable where UserId = " + UserId + " AND CateName = '" + param.getCateName() + "'";
		       stmt = conn.createStatement();
		       stmt.executeUpdate(strQuery);
	           flag = true;
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	      return flag;
	}
	
	public boolean getChange() {
	       Connection conn = null;
		   Statement stmt = null;
		   ResultSet rs = null;
		   boolean flag = false;	   
		   
	       try {
	           conn = pool.getConnection();
	           //1. �̸��Ͽ� �ش��ϴ� userID ����
		       String strQuery = "select UserId from usertable where Email = '" + Email + "'";
		       stmt = conn.createStatement();
		       rs = stmt.executeQuery(strQuery);
		       if(rs.next())
		    	   UserId = rs.getInt("UserId");
		       else{
		    	   pool.freeConnection(conn);
		    	   return false;
		       }
		       param.setUserId(UserId);
		       
		       //
		       strQuery = "select CateName from categorytable where CateName = '" + oldCateName + "'";
		       stmt = conn.createStatement();
		       rs = stmt.executeQuery(strQuery);
		       if(rs.next())
		       {
		    	   
		       }
		       else{
		    	   pool.freeConnection(conn);
		    	   return false;
		       }
		       //
		       
		       strQuery = "update categorytable set" + 
	           //"CateId = " + param.getCateId() +
	           //"UserId = " + param.getUserId() + 
	           " CateName = '" + newCateName +
	           //"CateUpdateTime = " + param.getCateUpdateTime() + 
	           "' where UserId = " + UserId + " AND CateName = '" + param.getCateName() + "'";
	           stmt = conn.createStatement();
	           stmt.executeUpdate(strQuery);
	           flag = true;
	       } catch (Exception ex) {
	          System.out.println("Exception" + ex);
	       } finally {
		      pool.freeConnection(conn);
	       }
	       return flag;
	}
}
