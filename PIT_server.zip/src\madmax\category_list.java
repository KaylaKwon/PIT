package madmax;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class category_list
 */
@WebServlet("/category_list")
public class category_list extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public category_list() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String Email = "";
		Email = request.getParameter("Email");
		categoryMgr mgr = new categoryMgr();
		mgr.setEmail(Email);
		Vector result = mgr.getList(); 
		
		Gson gson = new Gson();
		PrintWriter out = response.getWriter();
		if(result == null){
			System.out.println("fail");
			out.print(gson.toJson(null));	
		}
		else if(result.size() == 0){
			System.out.println("fail");
			out.print(gson.toJson(null));	
	    }else{
	    	System.out.println("succese");
	    	//System.out.println(gson.toJson(result));
	        out.print(gson.toJson(result));
	    }
	         	
	}

}
