package madmax;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Servlet implementation class sign_up
 */
@WebServlet("/sign_up")
public class sign_up extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sign_up() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			doPost(request, response);
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		UserBean bean = new UserBean();
		byte[] _input = Charset.forName("ISO-8859-1").encode(request.getParameter("Email")).array();
		String tempemail = new String(_input, Charset.forName("UTF-8"));
		System.out.println(tempemail);
		
		bean.setEmail(request.getParameter("Email"));
		//bean.setEmail(tempemail);
		bean.setPassWord(request.getParameter("PassWord"));
		System.out.println(request.getParameter("Email") + " " + request.getParameter("PassWord"));
		signupMgr mgr = new signupMgr();
		mgr.setParam(bean);
		
		Gson gson = new Gson();
		PrintWriter out = response.getWriter();
		if(mgr.getResult()){
			System.out.println("success");
			out.print(gson.toJson(true));
		}else{
			out.print(gson.toJson(false));
		}
	}

}
