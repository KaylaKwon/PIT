-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema pit_db
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema pit_db
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `pit_db` DEFAULT CHARACTER SET utf8 ;
USE `pit_db` ;

-- -----------------------------------------------------
-- Table `pit_db`.`usertable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pit_db`.`usertable` (
  `UserId` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Email` VARCHAR(45) NOT NULL COMMENT '',
  `PassWord` VARCHAR(45) NOT NULL COMMENT '',
  PRIMARY KEY (`UserId`)  COMMENT '')
ENGINE = InnoDB
AUTO_INCREMENT = 33
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `pit_db`.`categorytable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pit_db`.`categorytable` (
  `CateId` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `UserId` INT(11) NOT NULL COMMENT '',
  `CateName` VARCHAR(45) NOT NULL COMMENT '',
  `CateUpdateTime` VARCHAR(45) NOT NULL COMMENT '',
  PRIMARY KEY (`CateId`)  COMMENT '',
  INDEX `fk_categorytable_usertable1_idx` (`UserId` ASC)  COMMENT '',
  CONSTRAINT `fk_categorytable_usertable1`
    FOREIGN KEY (`UserId`)
    REFERENCES `pit_db`.`usertable` (`UserId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 21
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `pit_db`.`projecttable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pit_db`.`projecttable` (
  `ProjectId` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `CateId` INT(11) NOT NULL COMMENT '',
  `UserId` INT(11) NOT NULL COMMENT '',
  `ProjectName` VARCHAR(45) NOT NULL COMMENT '',
  `ProjectUpdateTime` VARCHAR(45) NOT NULL COMMENT '',
  `ProjectBriefy` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `ProjectPercent` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `StartDate` VARCHAR(45) NOT NULL COMMENT '',
  `EndDate` VARCHAR(45) NOT NULL COMMENT '',
  `startMoney` INT(11) NULL DEFAULT NULL COMMENT '',
  `endMoney` INT(11) NULL DEFAULT NULL COMMENT '',
  `startMoneyDate` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `endMoneyDate` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  PRIMARY KEY (`ProjectId`)  COMMENT '',
  INDEX `fk_projecttable_usertable1_idx` (`UserId` ASC)  COMMENT '',
  INDEX `fk_projecttable_categorytable1_idx` (`CateId` ASC)  COMMENT '',
  CONSTRAINT `fk_projecttable_categorytable1`
    FOREIGN KEY (`CateId`)
    REFERENCES `pit_db`.`categorytable` (`CateId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_projecttable_usertable1`
    FOREIGN KEY (`UserId`)
    REFERENCES `pit_db`.`usertable` (`UserId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 14
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `pit_db`.`todotable`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `pit_db`.`todotable` (
  `UserId` INT(11) NOT NULL COMMENT '',
  `CateId` INT(11) NOT NULL COMMENT '',
  `ProjectId` INT(11) NOT NULL COMMENT '',
  `ToDoName` VARCHAR(45) NOT NULL COMMENT '',
  `state` INT(11) NOT NULL COMMENT '',
  `ToDoStartDate` VARCHAR(45) NOT NULL COMMENT '',
  `ToDoEndDate` VARCHAR(45) NOT NULL COMMENT '',
  INDEX `fk_todotable_usertable_idx` (`UserId` ASC)  COMMENT '',
  INDEX `fk_todotable_projecttable1_idx` (`ProjectId` ASC)  COMMENT '',
  INDEX `fk_todotable_categorytable1_idx` (`CateId` ASC)  COMMENT '',
  CONSTRAINT `fk_todotable_categorytable1`
    FOREIGN KEY (`CateId`)
    REFERENCES `pit_db`.`categorytable` (`CateId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_todotable_projecttable1`
    FOREIGN KEY (`ProjectId`)
    REFERENCES `pit_db`.`projecttable` (`ProjectId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_todotable_usertable`
    FOREIGN KEY (`UserId`)
    REFERENCES `pit_db`.`usertable` (`UserId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
